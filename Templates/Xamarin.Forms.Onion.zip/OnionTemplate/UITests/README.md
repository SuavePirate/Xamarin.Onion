﻿# UI Tests	

This is where the general cross-platform UITests should be created and run from.
Platform specific test projects can also be added to the Tests folder in the solution