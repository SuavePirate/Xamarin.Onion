﻿# Android Platform

This is the android application project. This is where all Android specific controls, renderers, services, etc. are defined and implemented.
This is also where Android Resources such as image, sound, style, or other files are located.

This project should only reference the Client projects, including Controls

Custom Renderers should be defined in the *Renderers* folder
Native Service implementations should be defined in the *Services* folder