﻿# Android Binding Example	

This is just an example of where a Binding Library should be