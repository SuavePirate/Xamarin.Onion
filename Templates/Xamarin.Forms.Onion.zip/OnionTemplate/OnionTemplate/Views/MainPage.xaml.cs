﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace OnionTemplate
{
	public partial class MainPage : ContentPage
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
