﻿# Services

 Services define our business logic. They can be used to manipulate business/transfer models as well as data models.
 These services should not return data models, but should return "Data Transfer Objects" or DTOs that can be accessed by the client layer. 