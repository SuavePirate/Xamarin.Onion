﻿# Application Interfaces

This section defines our business logic services and managers.
This project should only reference the Application Models since the input and output of our logic should be DTOs