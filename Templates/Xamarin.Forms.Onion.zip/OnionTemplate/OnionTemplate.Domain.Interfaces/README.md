﻿# Domain Interfaces

This section defines our data access layer

This project should only reference the Domain Models project. It should contain no logic, or additional references or packages beyond what is used to define our data access layer.

## Sections

### Data Providers

These are used for accessing external data and bringing it into the app

### Repositories

These are for accessing internal data within the app