﻿# Repositories

This is where we define our local data access layer. The implementation of these definitions can interact with things like Sql Lite, file storage, or even just memory storage.