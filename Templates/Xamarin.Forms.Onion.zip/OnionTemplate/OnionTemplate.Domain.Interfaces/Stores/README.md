﻿# Stores

This is where our definitions of local memory stores go