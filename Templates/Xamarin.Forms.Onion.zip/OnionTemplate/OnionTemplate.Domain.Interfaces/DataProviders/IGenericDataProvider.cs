﻿using System;
namespace OnionTemplate.Domain.Interfaces.DataProviders
{
	/// <summary>
	/// Base definition for a data provider
	/// </summary>
	public interface IGenericDataProvider<T>
	{
	}
}
