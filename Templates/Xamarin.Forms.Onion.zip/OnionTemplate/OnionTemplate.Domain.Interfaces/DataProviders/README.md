﻿# Data Providers

These definitions are for providers of data. The implementation of these interfaces can interact with web services like Web API, WFC, SignalR, or other Third Party services such as cloud storage.