﻿# Domain Models

This section defines our data models. These models are used for storing, but should not be directly used to display.

This project should not reference any other project in the solution and should avoid any additional references or packages beyond what is required to define our models. 
You made need an additional package to define some data attributes if it is unavoidable.