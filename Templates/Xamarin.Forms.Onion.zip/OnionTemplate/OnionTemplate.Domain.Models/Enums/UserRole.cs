﻿using System;
namespace OnionTemplate.Domain.Models.Enums
{
	public enum UserRole
	{
		Admin,
		Author,
		Viewer
	}
}
