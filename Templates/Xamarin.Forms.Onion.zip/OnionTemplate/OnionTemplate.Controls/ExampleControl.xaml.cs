﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace OnionTemplate.Controls
{
	public partial class ExampleControl : ContentView
	{
		public ExampleControl()
		{
			InitializeComponent();
		}
	}
}
