﻿# Control Models

This is where models that custom controls require should be defined.