﻿# iOS Platform

This is the iOS application project. This is where all iOS specific controls, renderers, services, etc. are defined and implemented.
This is also where iOS assets such as image, sound, or other files are located.

This project should only reference the Client projects, including Controls

Custom Renderers should be defined in the *Renderers* folder
Native Service implementations should be defined in the *Services* folder